create definer = bookseller@localhost view vw_sale_details as
select `sd`.`sale`                                       AS `sale`,
       `sd`.`sale_detail_id`                             AS `sale_detail_id`,
       `sd`.`price`                                      AS `price`,
       `sd`.`quantity`                                   AS `quantity`,
       `sd`.`total`                                      AS `total`,
       `s`.`sales_reference`                             AS `sales_reference`,
       `c`.`category_name`                               AS `category_name`,
       `b`.`category`                                    AS `category`,
       `b`.`book_cover`                                  AS `book_cover`,
       concat_ws(' ', `a`.`first_name`, `a`.`last_name`) AS `author_name`,
       `sd`.`book`                                       AS `book`,
       `b`.`book_title`                                  AS `book_title`,
       `b`.`author`                                      AS `author`,
       `s`.`sale_date`                                   AS `sale_date`
from ((((`innov8_bookshop`.`tbl_sale_details` `sd` join `innov8_bookshop`.`tbl_sales` `s` on (`sd`.`sale` = `s`.`sale_id`)) join `innov8_bookshop`.`tbl_books` `b` on (`sd`.`book` = `b`.`book_id`)) join `innov8_bookshop`.`tbl_authors` `a` on (`b`.`author` = `a`.`author_id`))
         join `innov8_bookshop`.`tbl_categories` `c` on (`b`.`category` = `c`.`category_id`));

