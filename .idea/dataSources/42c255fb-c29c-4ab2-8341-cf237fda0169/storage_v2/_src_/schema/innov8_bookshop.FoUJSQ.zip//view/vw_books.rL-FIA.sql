create definer = bookseller@localhost view vw_books as
select `b`.`book_id`                                     AS `book_id`,
       format(`b`.`price`, 2)                            AS `price`,
       `b`.`deleted`                                     AS `deleted`,
       `b`.`category`                                    AS `category`,
       `c`.`category_name`                               AS `category_name`,
       `b`.`author`                                      AS `author`,
       `b`.`date_added`                                  AS `date_added`,
       `b`.`book_cover`                                  AS `book_cover`,
       `b`.`book_title`                                  AS `book_title`,
       `b`.`synopsis`                                    AS `synopsis`,
       `b`.`quantity_in_stock`                           AS `quantity_in_stock`,
       concat_ws(' ', `a`.`first_name`, `a`.`last_name`) AS `author_name`,
       concat_ws(' ', `u`.`first_name`, `u`.`last_name`) AS `created_user`
from (((`innov8_bookshop`.`tbl_books` `b` join `innov8_bookshop`.`tbl_users` `u` on (`b`.`user` = `u`.`user_id`)) join `innov8_bookshop`.`tbl_authors` `a` on (`b`.`author` = `a`.`author_id`))
         join `innov8_bookshop`.`tbl_categories` `c` on (`b`.`category` = `c`.`category_id`));

