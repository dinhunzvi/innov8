create view vw_sales as
select `s`.`sale_id`                                AS `sale_id`,
       `s`.`sale_date`                              AS `sale_date`,
       `s`.`sales_reference`                        AS `sales_reference`,
       format(`s`.`amount`, 2)                      AS `amount`,
       concat_ws(`c`.`first_name`, `c`.`last_name`) AS `customer_name`,
       `s`.`customer`                               AS `customer`
from (`innov8_bookshop`.`tbl_sales` `s`
         join `innov8_bookshop`.`tbl_customers` `c` on (`s`.`customer` = `c`.`customer_id`));

