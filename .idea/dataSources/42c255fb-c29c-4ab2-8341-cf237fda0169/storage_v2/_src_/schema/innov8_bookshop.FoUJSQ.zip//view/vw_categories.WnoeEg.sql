create definer = bookseller@localhost view vw_categories as
select `c`.`category_id`                                 AS `category_id`,
       `c`.`category_name`                               AS `category_name`,
       concat_ws(' ', `u`.`first_name`, `u`.`last_name`) AS `added_by`,
       `c`.`deleted`                                     AS `deleted`
from (`innov8_bookshop`.`tbl_categories` `c`
         join `innov8_bookshop`.`tbl_users` `u` on (`c`.`user` = `u`.`user_id`));

