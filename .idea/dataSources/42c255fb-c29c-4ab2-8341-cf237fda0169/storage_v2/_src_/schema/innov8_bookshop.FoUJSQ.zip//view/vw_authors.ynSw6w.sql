create definer = bookseller@localhost view vw_authors as
select concat_ws(' ', `a`.`first_name`, `a`.`last_name`) AS `author_name`,
       `a`.`author_id`                                   AS `author_id`,
       `a`.`deleted`                                     AS `deleted`,
       concat_ws(' ', `u`.`first_name`, `u`.`last_name`) AS `created_user`
from (`innov8_bookshop`.`tbl_authors` `a`
         join `innov8_bookshop`.`tbl_users` `u` on (`a`.`user` = `u`.`user_id`));

